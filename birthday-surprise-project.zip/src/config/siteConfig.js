import photo1 from '../assets/images/memory-01.jpg';
import photo2 from '../assets/images/memory-02.jpg';
import photo3 from '../assets/images/memory-03.jpg';
import photo4 from '../assets/images/memory-04.jpg';

// EDIT THIS FILE to personalise the whole experience.
export const siteConfig = {
  girlfriendName: 'My Favourite Person',
  senderName: 'Someone who cares about you',
  birthdayDate: '2026-12-01', // YYYY-MM-DD; update this to the real birthday.
  pin: '2026', // Personal surprise gate only; not secure authentication.
  heroMessage: 'Some people make ordinary days feel a little more beautiful. You are one of them.',
  letter: `Happy Birthday!\n\nI hope this year brings you the kind of happiness that stays, the kind of peace that makes everything feel lighter, and plenty of little reasons to smile.\n\nI wanted to make something that feels a little more personal than a simple birthday message. So here are a few moments, a few words, and a small reminder that you deserve to be celebrated.\n\nKeep being yourself, keep doing the things that make you happy, and never forget how special you are. Have the loveliest birthday.\n\nWith lots of good wishes,\n${'Someone who cares about you'}`,
  photos: {
    lock: photo4,
    hero: photo3,
    letter: photo2,
    finale: photo1,
    gallery: [photo1, photo2, photo3, photo4],
  },
  memories: [
    { date: 'A lovely little moment', title: 'The way you smile', caption: 'A simple moment, but one worth keeping.', image: photo1 },
    { date: 'A day to remember', title: 'The little details', caption: 'Sometimes the smallest details become our favourite memories.', image: photo2 },
    { date: 'One for the album', title: 'Just being you', caption: 'No grand occasion needed. You make the moment.', image: photo3 },
    { date: 'A favourite frame', title: 'A little happiness', caption: 'A photograph can hold a feeling for a long time.', image: photo4 },
  ],
  appreciations: [
    ['Your smile', 'It has a way of making even an ordinary moment feel brighter.'],
    ['Your kindness', 'The little thoughtful things you do say more than you realise.'],
    ['Your energy', 'There is something lovely about the way you bring your own spark into a room.'],
    ['Being yourself', 'You do not need to be anyone else to be worth celebrating.'],
  ],
  surpriseNote: 'One more reason to smile today: you deserve all the good things coming your way.',
  music: { title: 'A little birthday soundtrack', artist: 'Add your favourite song', audioFile: '' },
  voiceMessage: '',
  colors: { burgundy: '#4c1e30', ivory: '#f4ecdf', champagne: '#d8b77c' },
};
