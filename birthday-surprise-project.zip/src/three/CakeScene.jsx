import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function CakeScene({ blown }) {
  const mount = useRef(null);
  useEffect(() => {
    const host = mount.current; if (!host) return;
    let renderer;
    try {
      const scene = new THREE.Scene(); scene.background = null;
      const camera = new THREE.PerspectiveCamera(34, host.clientWidth / 260, 0.1, 100); camera.position.set(0, 3.8, 8.5); camera.lookAt(0, 1.1, 0);
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6)); renderer.setSize(host.clientWidth, 260); renderer.shadowMap.enabled = true; host.appendChild(renderer.domElement);
      scene.add(new THREE.AmbientLight(0xffe7d2, 2.1)); const light = new THREE.DirectionalLight(0xffd39b, 3); light.position.set(4, 7, 5); light.castShadow = true; scene.add(light);
      const cakeMat = new THREE.MeshStandardMaterial({ color: 0xead3c2, roughness: .48 }); const trim = new THREE.MeshStandardMaterial({ color: 0xb77b70, roughness: .35 });
      const addCylinder = (r1,r2,h,y,mat) => { const mesh = new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,64),mat); mesh.position.y=y; mesh.castShadow=true; mesh.receiveShadow=true; scene.add(mesh); };
      addCylinder(1.65,1.65,.72,.48,cakeMat); addCylinder(1.25,1.25,.66,1.15,cakeMat); addCylinder(1.65,1.65,.09,.88,trim); addCylinder(1.25,1.25,.08,1.51,trim);
      const candles=[];
      for(let i=0;i<5;i++){ const a=(i/5)*Math.PI*2; const x=Math.cos(a)*.72,z=Math.sin(a)*.72; const stick=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.48,12),new THREE.MeshStandardMaterial({color:0xfff1d7})); stick.position.set(x,1.72,z); scene.add(stick); const flame=new THREE.Mesh(new THREE.SphereGeometry(.085,12,12),new THREE.MeshBasicMaterial({color:0xffb34f})); flame.scale.set(.72,1.5,.72); flame.position.set(x,2.02,z); scene.add(flame); candles.push(flame); }
      const floor=new THREE.Mesh(new THREE.CircleGeometry(3,64),new THREE.MeshStandardMaterial({color:0x3c202b,roughness:1})); floor.rotation.x=-Math.PI/2; floor.position.y=.05; floor.receiveShadow=true; scene.add(floor);
      let frame; let t=0; const animate=()=>{frame=requestAnimationFrame(animate);t+=.02; scene.rotation.y=Math.sin(t*.35)*.08; candles.forEach((f,i)=>{f.visible=!blown;f.scale.y=1.35+Math.sin(t*5+i)*.18;}); renderer.render(scene,camera);}; animate();
      const resize=()=>{camera.aspect=host.clientWidth/260;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,260);}; window.addEventListener('resize',resize);
      return ()=>{cancelAnimationFrame(frame);window.removeEventListener('resize',resize);renderer.dispose();host.innerHTML='';scene.traverse(o=>{o.geometry?.dispose?.(); if(o.material){if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material.dispose();}});};
    } catch { host.innerHTML='<div class="cake-fallback">🎂</div>'; }
  }, [blown]);
  return <div className="cake-scene" ref={mount} aria-label="A layered birthday cake with candles" />;
}
